import React from 'react';

const Forth = () => {
    return (
        <div>
            <h2>네번째 이벤트 정보입니다.</h2>
        </div>
    );
};

export default Forth;