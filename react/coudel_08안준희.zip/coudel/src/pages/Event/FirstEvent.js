import React from 'react';

const First = () => {
    return (
        <div>
            <h2>첫번째 이벤트 정보입니다.</h2>
        </div>
    );
};

export default First;