import React from 'react';

const Third = () => {
    return (
        <div>
            <h2>세번째 이벤트 정보입니다.</h2>
        </div>
    );
};

export default Third;