import React from "react";

const ForthCoupon = () => {
  return (
    <div>
      <h2>데이터 쿠폰입니다.</h2>
      <p>통신사 데이터 쿠폰 관련 이미지 공간</p>
    </div>
  );
};

export default ForthCoupon;
