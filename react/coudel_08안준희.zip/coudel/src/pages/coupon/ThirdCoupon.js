import React from 'react';

const ThirdCoupon = () => {
    return (
        <div>
            <h2>세번째 쿠폰정보입니다.</h2>
        </div>
    );
};

export default ThirdCoupon;