import React from 'react';

const SecondCoupon = () => {
    return (
        <div>
            <h2>두번째 쿠폰 정보입니다.</h2>
        </div>
    );
};

export default SecondCoupon;