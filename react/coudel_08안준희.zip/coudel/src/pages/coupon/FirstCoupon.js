import React from "react";

const FirstCoupon = () => {
  return (
    <div>
      <h2>첫번째 쿠폰 정보입니다.</h2>
    </div>
  );
};

export default FirstCoupon;
