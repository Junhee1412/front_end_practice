import React from "react";
import MyComponent from "./MyComponent";
import MyCom_class from "./MyCom_class";
import Counter from "./Counter";
import Say from "./Say";

const App = () => {
  return (
    <>
      <div>
        <MyComponent name="react" favoriteNumber={1}>
          리액트
        </MyComponent>
      </div>
      <div>
        <hr />
        <MyCom_class name="react_class" favoriteNumber={4}>
          클래스
        </MyCom_class>
      </div>
      <hr />
      <div>
        <h2>클래스 컴포넌트에서 state 사용하기</h2>
        <Counter />
      </div>
      <hr />
      <div>
        <h2>함수 컴포넌트에서 useState 사용하기</h2>
        <Say />
      </div>
      <hr />
    </>
  );
};

export default App;
